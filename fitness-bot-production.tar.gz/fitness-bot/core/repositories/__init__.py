"""
Repository pattern implementations
"""
