"""
Pydantic схемы
"""
