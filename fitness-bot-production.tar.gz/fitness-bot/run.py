#!/usr/bin/env python3
"""
Скрипт запуска бота
"""
import asyncio
from bot.main import main

if __name__ == "__main__":
    asyncio.run(main())
